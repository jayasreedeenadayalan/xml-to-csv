<?php
// create Class for xmt to csv convertor
Class XmlConvertor{
  public function index(){
	if(!empty($_FILES)){
		$filexml = $_FILES['fileToUpload']['name'];
	    if (file_exists($filexml)){
			//get file extension
			$ext = pathinfo($filexml, PATHINFO_EXTENSION);
			//Check the File Extension
			if($ext == 'xml'){
				$xml = simplexml_load_file($filexml);
				$pth = 'CsvFiles/'.time().'.csv';
				$f = fopen($pth, 'w');
				$header = array();
				foreach($xml as $key => $value){
					if(!$header) {
					//convert xml to csv
						fputcsv($f, array_keys(get_object_vars($value)));
						$header = true;
					}
					fputcsv($f, get_object_vars($value));
				}
				echo '<a href="'.$pth.'">Download CSV</a></br>';
	 
				fclose($f);
				echo "file converted successfully";
			}else{
				echo "please upload XML files Only";
			}
			
		}
	}else{
		echo "Please Upload XML file";
		exit;
	}
  }
  
}

?>