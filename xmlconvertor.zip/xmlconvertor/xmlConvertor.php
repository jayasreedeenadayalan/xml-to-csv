<?php
require_once('index.php');

if(!empty($_FILES)){
   
   $csv = $ObjXmlConvert->index();
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Xml to CSV Convertor</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME']?>/xmlconvertor/css/bootstrap.min.css">
  <script src="<?php echo $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME'] ?>/xmlconvertor/js/jquery.min.js"></script>
  <script src="<?php echo $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME'] ?>/xmlconvertor/js/bootstrap.min.js"></script>
  <script src="<?php echo $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME'] ?>/xmlconvertor/js/validate.js"></script>
</head>
<body>
<div class="container">
  <h2>XML to CSV Convertor</h2>
  <form action="xmlConvertor.php" method="POST" id="fileLoad" enctype="multipart/form-data">
    <div class="form-group">
      <label for="fileupload">Select XML File to upload:</label>
      <input type="file" class="form-control" id="fileToUpload" name="fileToUpload">
	  <span id="FilesupErr"></span>
    </div>
    <button type="submit" name="submit"  onclick="return validate();" class="btn btn-success">Submit</button>
  </form>
</div>
<script type="text/javascript">
    $(document).ready(function(){
     
        $('input[type="file"]').change(function(e){
            var fileName = e.target.files[0].name;
			$("#FilesupErr").html("");
			var ext = fileName.split('.').pop();
			if(ext != 'xml'){
				$("#FilesupErr").css({'color':'#ff0000'}).html('Please upload xml files only');
				return false;
			}else{
				$("#fileLoad").submit();
				return false;
			}
		});
        
    });
</script>

</body>

</html>

