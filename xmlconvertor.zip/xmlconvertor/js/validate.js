function validate(){

   var files = $("#fileToUpload").val();
   if(files == ''){
		$("#FilesupErr").css({'color':'#ff0000'}).html('Please upload xml files');
		return false;
   }
}